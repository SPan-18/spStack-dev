# spStack 1.0.1

* Fix a minor memory leak.

# spStack 1.0.0

* Initial CRAN submission.
