#' Univariate spatial generalized linear model
#'
#' @description Fits a Bayesian spatial generalized linear model with spatial
#'  process parameters and some auxiliary model parameters fixed to a value
#'  supplied by the user. The output contains posterior samples of the fixed
#'  effects, variance parameter, spatial random effects and, if required,
#'  leave-one-out predictive densities.
#' @param formula a symbolic description of the regression model to be fit.
#'  See example below.
#' @param data an optional data frame containing the variables in the model.
#'  If not found in \code{data}, the variables are taken from
#'  \code{environment(formula)}, typically the environment from which
#'  \code{spGLMexact} is called.
#' @param coords an \eqn{n \times 2}{n x 2} matrix of the observation
#'  coordinates in \eqn{\mathbb{R}^2} (e.g., easting and northing).
#' @param cor.fn a quoted keyword that specifies the correlation function used
#'  to model the spatial dependence structure among the observations. Supported
#'  covariance model key words are: \code{'exponential'} and \code{'matern'}.
#'  See below for details.
#' @param priors a list with each tag corresponding to a hyperparameter name and
#'  containing hyperprior details. Default is
#'  `list(nu.beta = 2.1, nu.z = 2.1, sigmSq.xi = 1)`.
#' @param spParams fixed value of spatial process parameters.
#' @param boundary (optional) a real number greater than 0 and less than 1.
#'  Default is 0.5.
#' @param n.samples number of posterior samples to be generated.
#' @param loopd logical. If `loopd=TRUE`, returns leave-one-out predictive
#'  densities, using method as given by \code{loopd.method}. Deafult is
#'  \code{FALSE}.
#' @param loopd.method character. Ignored if `loopd=FALSE`. If `loopd=TRUE`,
#'  valid inputs are `'exact'` and `'PSIS'`. The option `'exact'` corresponds to
#'  exact leave-one-out predictive densities which requires computation almost
#'  equivalent to fitting the model \eqn{n} times. The option `'PSIS'` is
#'  faster and finds approximate leave-one-out predictive densities using
#'  Pareto-smoothed importance sampling (Gelman *et al.* 2024).
#' @param verbose logical. If \code{verbose = TRUE}, prints model description.
#' @param ... currently no additional argument.
#' @seealso [spLMexact()]
#' @references Vehtari A, Simpson D, Gelman A, Yao Y, Gabry J (2024). “Pareto
#'  Smoothed Importance Sampling.” *Journal of Machine Learning Research*,
#'  **25**(72), 1–58. URL \url{https://jmlr.org/papers/v25/19-556.html}.
#' @export
spGLMexact <- function(formula, data = parent.frame(), coords, cor.fn, priors,
                       spParams, boundary = 0.5, n.samples,
                       loopd = FALSE, loopd.method = "exact",
                       verbose = TRUE, ...){

  ##### check for unused args #####
  formal.args <- names(formals(sys.function(sys.parent())))
  elip.args <- names(list(...))
  for(i in elip.args){
    if (!i %in% formal.args)
      warning("'", i, "' is not an argument")
  }

  ##### formula #####
  if(missing(formula)){
    stop("error: formula must be specified!")
  }

  if(inherits(formula, "formula")){
    holder <- parseFormula(formula, data)
    y <- holder[[1]]
    X <- as.matrix(holder[[2]])
    X.names <- holder[[3]]
  } else {
    stop("error: formula is misspecified")
  }

  p <- ncol(X)
  n <- nrow(X)

  ## storage mode
  storage.mode(y) <- "double"
  storage.mode(X) <- "double"
  storage.mode(p) <- "integer"
  storage.mode(n) <- "integer"

  ##### coords #####
  if(!is.matrix(coords)){
    stop("error: coords must n-by-2 matrix of xy-coordinate locations")
  }
  if(ncol(coords) != 2 || nrow(coords) != n){
    stop("error: either the coords have more than two columns or,
    number of rows is different than data used in the model formula")
  }

  coords.D <- 0
  coords.D <- iDist(coords)

  ##### correlation function #####
  if(missing(cor.fn)){
    stop("error: cor.fn must be specified")
  }
  if(!cor.fn %in% c("exponential", "matern")){
    stop("cor.fn = '", cor.fn, "' is not a valid option; choose from
         c('exponential', 'matern').")
  }

  ##### priors #####
  

  return(0.0)
}